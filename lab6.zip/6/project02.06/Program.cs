﻿var builder = WebApplication.CreateBuilder();

var app = builder.Build();

int x = 4;
app.Run(async (context) =>
{
    x = x * 2; 
    await context.Response.WriteAsync($"Result: {x}");
});
app.Run();
